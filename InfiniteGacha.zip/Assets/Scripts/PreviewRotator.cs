using UnityEngine;

/// Rotaciona o GameObject lentamente em torno de um eixo.
/// - speed: graus por segundo (padrão 15). Use valores positivos para girar em sentido horário (quando visto de cima).
/// - axis: eixo de rotação (padrão Vector3.up).
public class PreviewRotator : MonoBehaviour
{
    public float speed = 15f;
    public Vector3 axis = Vector3.up;

    void Update()
    {
        if (Mathf.Abs(speed) > 0.0001f)
        {
            // rotaciona no espaço mundial para manter comportamento consistente independentemente da hierarquia
            transform.Rotate(axis.normalized, speed * Time.deltaTime, Space.World);
        }
    }
}