using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// GachaUI - Gerencia a interface do gacha: botões de pull, exibição de resultados UI (grid/scroll)
/// e previews (por padrão via RenderTexture/RawImage em ResultSlot).
///
/// Para evitar que objetos 3D sejam instanciados "no fundo" do mundo, a flag
/// enableWorldPreviews está desativada por padrão. Se quiser reativar previews em world space,
/// marque enableWorldPreviews = true no Inspector (mas atenção: isso volta a instanciar objetos na cena).
public class GachaUI : MonoBehaviour
{
    [Header("Managers & Data")]
    public GachaSystem gacha;
    public CurrencyManager currency;
    public InventoryManager inventory;

    [Header("Costs")]
    public int costPerPull = 100;

    [Header("UI References")]
    public Text gemsText;
    public Transform resultsContainer;      // Content do Scroll View (GridLayoutGroup)
    public GameObject resultSlotPrefab;     // prefab UI do slot (com ResultSlot)
    public ScrollRect resultsScrollRect;    // ScrollRect do Scroll View

    [Header("World 3D Previews (disabled by default)")]
    [Tooltip("Quando false, NÃO irão ser instanciados modelos 3D no mundo — apenas os previews em panel (RenderTexture).")]
    public bool enableWorldPreviews = false;
    public Transform results3DParent;       // opcional - usado apenas se enableWorldPreviews == true
    public Transform previewSpawnPoint;     // opcional - usado apenas se enableWorldPreviews == true
    public float previewSpacing = 1.2f;
    public float previewScale = 1f;
    public float previewLift = 0.5f;

    // estado runtime
    private GameObject currentPreviewInstance;

    void Start()
    {
        if (gacha == null) Debug.LogWarning("GachaUI: gacha não atribuído.");
        if (currency == null) Debug.LogWarning("GachaUI: currency não atribuído.");
        if (resultsContainer == null) Debug.LogWarning("GachaUI: resultsContainer não atribuído.");
        if (resultSlotPrefab == null) Debug.LogWarning("GachaUI: resultSlotPrefab não atribuído.");
        if (resultsScrollRect == null) Debug.LogWarning("GachaUI: resultsScrollRect não atribuído.");

        // Se world previews estiverem desativados, limpe quaisquer objetos já existentes no results3DParent
        if (!enableWorldPreviews && results3DParent != null)
        {
            for (int i = results3DParent.childCount - 1; i >= 0; i--)
                Destroy(results3DParent.GetChild(i).gameObject);
        }
    }

    void Update()
    {
        if (gemsText != null && currency != null)
            gemsText.text = $"Gems: {currency.gems}";
    }

    // --- Botões públicos ---
    public void OnPullOnce()
    {
        if (currency == null || gacha == null) return;

        if (!currency.Spend(costPerPull))
        {
            Debug.Log("GachaUI: gems insuficientes para 1 pull.");
            return;
        }

        List<CharacterData> results = gacha.Pull(1);
        HandleResults(results);
    }

    public void OnPullTen()
    {
        if (currency == null || gacha == null) return;

        int totalCost = costPerPull * 10;
        if (!currency.Spend(totalCost))
        {
            Debug.Log("GachaUI: gems insuficientes para 10 pulls.");
            return;
        }

        List<CharacterData> results = gacha.Pull(10);
        HandleResults(results);
    }

    // --- Processa resultados ---
    void HandleResults(List<CharacterData> results)
    {
        if (results == null || results.Count == 0)
        {
            Debug.Log("GachaUI: Nenhum resultado retornado.");
            return;
        }

        AppendResultsUI(results);

        // Se a flag estiver ativa, exibimos também previews world-space (desativado por padrão)
        if (enableWorldPreviews)
            ShowResults3D(results);

        if (inventory != null)
        {
            foreach (var r in results)
                inventory.Add(r);
        }
    }

    // --- UI: adiciona slots ao container (append) ---
    void AppendResultsUI(List<CharacterData> results)
    {
        if (resultsContainer == null || resultSlotPrefab == null)
        {
            Debug.LogWarning("AppendResultsUI: resultsContainer ou resultSlotPrefab não atribuídos.");
            return;
        }

        // instancia e preenche slots
        for (int i = 0; i < results.Count; i++)
        {
            var data = results[i];
            var go = Instantiate(resultSlotPrefab);
            go.transform.SetParent(resultsContainer, false);
            go.transform.localScale = Vector3.one;

            // se prefab tem ResultSlot, usa SetData (onde ResultSlot cuidará do preview via PreviewRenderer)
            var slotComp = go.GetComponent<ResultSlot>();
            if (slotComp != null)
            {
                slotComp.SetData(data);
            }
            else
            {
                var txt = go.GetComponentInChildren<Text>();
                var img = go.GetComponentInChildren<Image>();
                if (txt != null) txt.text = data?.displayName ?? "(sem nome)";
                if (img != null && data?.sprite != null) img.sprite = data.sprite;
            }

            var btn = go.GetComponentInChildren<Button>();
            if (btn != null)
            {
                btn.onClick.RemoveAllListeners();
                CharacterData captured = data;
                btn.onClick.AddListener(() => Show3DPreview(captured));
            }

            // garante que o RectTransform do slot coincide com o cellSize do Grid (opcional)
            var rt = go.GetComponent<RectTransform>();
            var grid = resultsContainer.GetComponent<UnityEngine.UI.GridLayoutGroup>();
            if (rt != null && grid != null)
            {
                rt.sizeDelta = grid.cellSize;
            }
        }

        // força rebuild do layout
        var rect = resultsContainer as RectTransform;
        if (rect != null)
            UnityEngine.UI.LayoutRebuilder.ForceRebuildLayoutImmediate(rect);

        if (resultsScrollRect != null)
            StartCoroutine(ScrollToBottomNextFrame());
    }

    IEnumerator ScrollToBottomNextFrame()
    {
        yield return null;
        if (resultsScrollRect == null) yield break;
        resultsScrollRect.verticalNormalizedPosition = 0f;
        yield return null;
    }

    // --- World 3D previews: só executa se enableWorldPreviews == true ---
    void ShowResults3D(List<CharacterData> results)
    {
        if (!enableWorldPreviews)
        {
            // Proteção: nada a fazer quando desabilitado.
            Debug.Log("ShowResults3D: world previews desabilitados por enableWorldPreviews = false.");
            return;
        }

        // (Se você ativar enableWorldPreviews, aqui pode ficar sua implementação anterior
        //  para instanciar modelos no mundo. Por enquanto deixei a lógica separada.)
        Debug.Log("ShowResults3D: chamada com enableWorldPreviews = true (implementar se desejar).");
    }

    // --- Preview único (quando clica no botão do slot) ---
    // Se world previews estão desabilitados, Show3DPreview apenas loga (você pode adaptar para abrir o RawImage do slot)
    public void Show3DPreview(CharacterData data)
    {
        if (!enableWorldPreviews)
        {
            Debug.Log("Show3DPreview: world previews desabilitados. Use o preview dentro do slot (RenderTexture).");
            return;
        }

        // se por algum motivo habilitar, mantenha a antiga lógica (implemente se necessário)
        Camera cam = Camera.main;
        Vector3 spawnPos = previewSpawnPoint != null ? previewSpawnPoint.position : (cam != null ? cam.transform.position + cam.transform.forward * 3f : Vector3.zero);
        if (data == null || data.prefab3D == null)
        {
            Debug.Log("Show3DPreview: dados nulos ou prefab3D ausente.");
            return;
        }

        if (currentPreviewInstance != null) Destroy(currentPreviewInstance);

        currentPreviewInstance = (results3DParent != null)
            ? Instantiate(data.prefab3D, spawnPos, Quaternion.identity, results3DParent)
            : Instantiate(data.prefab3D, spawnPos, Quaternion.identity);

        currentPreviewInstance.transform.localScale = Vector3.one * previewScale;
        var cols = currentPreviewInstance.GetComponentsInChildren<Collider>();
        foreach (var c in cols) c.enabled = false;

        if (cam != null)
        {
            Vector3 look = cam.transform.position - currentPreviewInstance.transform.position;
            look.y = 0f;
            if (look.sqrMagnitude > 0.0001f) currentPreviewInstance.transform.rotation = Quaternion.LookRotation(look);
        }

        currentPreviewInstance.transform.localScale = Vector3.zero;
        StartCoroutine(PopIn(currentPreviewInstance.transform, Vector3.one * previewScale, 0.2f));
    }

    IEnumerator PopIn(Transform t, Vector3 targetScale, float duration)
    {
        if (t == null) yield break;

        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float p = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(elapsed / duration));
            t.localScale = Vector3.Lerp(Vector3.zero, targetScale, p);
            yield return null;
        }
        t.localScale = targetScale;
    }

    // Limpa previews 3D (só aplicável se enableWorldPreviews == true)
    public void Clear3DPreview()
    {
        if (currentPreviewInstance != null) Destroy(currentPreviewInstance);

        if (results3DParent == null) return;
        for (int i = results3DParent.childCount - 1; i >= 0; i--)
            Destroy(results3DParent.GetChild(i).gameObject);
    }

    // OnDrawGizmosSelected removido para evitar confusão visual ao trabalhar apenas com panels.
}