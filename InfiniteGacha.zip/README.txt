📌 Visão Geral

Este projeto implementa um sistema básico de Gacha inspirado no manhwa Pick Me Up, Infinite Gacha.
Ao iniciar a cena (Play), o jogador vê uma interface simples com contador de gemas e botões para realizar invocações.

O sistema atualmente realiza:

Exibição de painel inicial vazio

Contador de Gems no canto superior esquerdo

Botões Pull 1x e Pull 10x no canto inferior central

Invocação de heróis

Exibição de prévia 3D simples (um cubo colorido conforme raridade) rotacionando lentamente

Botão Visualizar para abrir o painel detalhado do herói

Painel de visualização ainda não funcionando devido a preview desativado

🖥️ Fluxo da Interface
🔹 Tela Inicial (ao clicar Play)

Aparece:

Painel em branco

Contador de Gems no topo esquerdo

Botões:

Pull 1x

Pull 10x

🔹 Ao clicar em Pull (1x ou 10x)

Para cada herói invocado:

Nome do herói

Um preview 3D simples

Atualmente representado por um cubo com cor correspondente à raridade

Rotação lenta horizontal (Y-axis)

Botão Visualizar

🔹 Ao clicar em “Visualizar”

O planejado:

Abrir um painel maior com:

Preview 3D ampliado

Nome do herói

Status

Botão Close

Status atual:

O painel não aparece

Unity exibe o erro:

Show3DPreview: world previews desabilitados.
Use o preview dentro do slot (RenderTexture).

⚠️ Problema Atual

O preview 3D maior (Hero Preview Panel) não aparece